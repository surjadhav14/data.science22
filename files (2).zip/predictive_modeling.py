"""
Predictive Modeling with Machine Learning
-----------------------------------------
Usage: python predictive_modeling.py [cleaned_csv]
Part A: Classification  - predict survival (Logistic Regression, Decision Tree, Random Forest)
Part B: Regression      - predict fare (Linear Regression, Random Forest Regressor)
Outputs: model_dashboard.png, model_report.txt
"""
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, confusion_matrix,
                             ConfusionMatrixDisplay, r2_score, mean_absolute_error)

PATH = sys.argv[1] if len(sys.argv) > 1 else "cleaned_data.csv"
SEED = 42
sns.set_theme(style="whitegrid")
out = []
def log(m=""):
    print(m); out.append(m)

df = pd.read_csv(PATH)

# ======================================================= PART A: CLASSIFICATION
# Drop columns that leak the target ('alive' == 'survived') or duplicate other columns.
target = "survived"
drop = ["alive", "class", "who", "adult_male", "embark_town", "alone", "age_group"]
X = df.drop(columns=[target] + [c for c in drop if c in df.columns])
y = df[target]

cat_cols = X.select_dtypes(exclude="number").columns.tolist()
num_cols = X.select_dtypes(include="number").columns.tolist()
log(f"Features -> numeric: {num_cols} | categorical: {cat_cols}")

pre = ColumnTransformer([
    ("num", StandardScaler(), num_cols),
    ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat_cols),
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=SEED)
log(f"Train = {X_train.shape}, Test = {X_test.shape}, "
    f"positive rate train/test = {y_train.mean():.2f}/{y_test.mean():.2f}\n")

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree": DecisionTreeClassifier(max_depth=4, random_state=SEED),
    "Random Forest": RandomForestClassifier(n_estimators=300, random_state=SEED),
}
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
fitted, rows = {}, []
for name, m in models.items():
    pipe = Pipeline([("pre", pre), ("model", m)])
    cv_acc = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="accuracy")
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    proba = pipe.predict_proba(X_test)[:, 1]
    fitted[name] = (pipe, pred, proba)
    rows.append({"Model": name,
                 "CV Acc (train)": f"{cv_acc.mean():.3f} +/- {cv_acc.std():.3f}",
                 "Test Acc": accuracy_score(y_test, pred),
                 "Precision": precision_score(y_test, pred),
                 "Recall": recall_score(y_test, pred),
                 "F1": f1_score(y_test, pred),
                 "ROC-AUC": roc_auc_score(y_test, proba)})
res = pd.DataFrame(rows).set_index("Model")
log("=== CLASSIFICATION RESULTS ===")
log(res.round(3).to_string())

# Hyperparameter tuning for the Random Forest
grid = GridSearchCV(
    Pipeline([("pre", pre), ("model", RandomForestClassifier(random_state=SEED))]),
    {"model__n_estimators": [200, 400],
     "model__max_depth": [4, 6, 8, None],
     "model__min_samples_leaf": [1, 3, 5]},
    cv=cv, scoring="roc_auc", n_jobs=-1).fit(X_train, y_train)
best = grid.best_estimator_
bp = best.predict(X_test); bpr = best.predict_proba(X_test)[:, 1]
log(f"\nTuned RF best params: {grid.best_params_}")
log(f"Tuned RF -> Test Acc {accuracy_score(y_test, bp):.3f} | "
    f"F1 {f1_score(y_test, bp):.3f} | ROC-AUC {roc_auc_score(y_test, bpr):.3f}")
fitted["Tuned Random Forest"] = (best, bp, bpr)

# ======================================================= PART B: REGRESSION
Xr = df.drop(columns=["fare"] + [c for c in drop + [target] if c in df.columns])
yr = df["fare"]
cat_r = Xr.select_dtypes(exclude="number").columns.tolist()
num_r = Xr.select_dtypes(include="number").columns.tolist()
pre_r = ColumnTransformer([("num", StandardScaler(), num_r),
                           ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat_r)])
Xr_tr, Xr_te, yr_tr, yr_te = train_test_split(Xr, yr, test_size=0.2, random_state=SEED)
reg_rows, reg_pred = [], {}
for name, m in {"Linear Regression": LinearRegression(),
                "Random Forest Reg.": RandomForestRegressor(n_estimators=300, random_state=SEED)}.items():
    p = Pipeline([("pre", pre_r), ("model", m)]).fit(Xr_tr, yr_tr)
    pr = p.predict(Xr_te); reg_pred[name] = pr
    reg_rows.append({"Model": name, "R2": r2_score(yr_te, pr), "MAE": mean_absolute_error(yr_te, pr)})
log("\n=== REGRESSION RESULTS (predict fare) ===")
log(pd.DataFrame(reg_rows).set_index("Model").round(3).to_string())

# ======================================================= DASHBOARD
fig = plt.figure(figsize=(18, 13))
fig.suptitle("Predictive Modeling Dashboard - Titanic Survival & Fare",
             fontsize=21, fontweight="bold", y=0.98)
gs = fig.add_gridspec(3, 3, hspace=0.42, wspace=0.3)

# ROC curves
ax = fig.add_subplot(gs[0, 0])
for name, (_, _, pr) in fitted.items():
    fpr, tpr, _ = roc_curve(y_test, pr)
    ax.plot(fpr, tpr, lw=2, label=f"{name} (AUC {roc_auc_score(y_test, pr):.2f})")
ax.plot([0, 1], [0, 1], "k--", lw=1)
ax.set_title("ROC curves"); ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
ax.legend(fontsize=8, loc="lower right")

# Metric comparison
ax = fig.add_subplot(gs[0, 1:])
res[["Test Acc", "Precision", "Recall", "F1", "ROC-AUC"]].plot.bar(ax=ax, rot=0, width=0.8)
ax.set_ylim(0.5, 1); ax.set_title("Test-set metrics by model"); ax.legend(ncol=5, fontsize=8)

# Confusion matrices (3 models)
for i, name in enumerate(["Logistic Regression", "Decision Tree", "Tuned Random Forest"]):
    ax = fig.add_subplot(gs[1, i])
    ConfusionMatrixDisplay(confusion_matrix(y_test, fitted[name][1]),
                           display_labels=["Died", "Survived"]).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"Confusion matrix - {name}"); ax.grid(False)

# Feature importance (tuned RF)
ax = fig.add_subplot(gs[2, 0])
names = best.named_steps["pre"].get_feature_names_out()
imp = pd.Series(best.named_steps["model"].feature_importances_, index=names).sort_values().tail(8)
imp.index = [n.split("__")[1] for n in imp.index]
imp.plot.barh(ax=ax, color="#4c72b0"); ax.set_title("Top features (tuned Random Forest)")

# Regression: actual vs predicted
ax = fig.add_subplot(gs[2, 1])
for name, pr in reg_pred.items():
    ax.scatter(yr_te, pr, alpha=0.5, s=18, label=f"{name} (R2 {r2_score(yr_te, pr):.2f})")
lim = [0, yr_te.max()]; ax.plot(lim, lim, "k--", lw=1)
ax.set_title("Fare: actual vs predicted"); ax.set_xlabel("Actual"); ax.set_ylabel("Predicted"); ax.legend(fontsize=8)

# Decision tree depth vs accuracy (overfitting check)
ax = fig.add_subplot(gs[2, 2])
depths = range(1, 15); tr_s, te_s = [], []
for d in depths:
    p = Pipeline([("pre", pre), ("model", DecisionTreeClassifier(max_depth=d, random_state=SEED))]).fit(X_train, y_train)
    tr_s.append(p.score(X_train, y_train)); te_s.append(p.score(X_test, y_test))
ax.plot(depths, tr_s, label="Train"); ax.plot(depths, te_s, label="Test")
ax.set_title("Decision Tree: depth vs accuracy"); ax.set_xlabel("max_depth"); ax.legend()

plt.savefig("model_dashboard.png", dpi=150, bbox_inches="tight")
open("model_report.txt", "w").write("\n".join(out))
log("\nSaved model_dashboard.png and model_report.txt")
